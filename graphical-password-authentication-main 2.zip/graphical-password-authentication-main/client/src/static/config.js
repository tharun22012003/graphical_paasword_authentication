export const api = {
    //url: "http://localhost:5000"
    //url:"https://crazy-fish-tights.cyclic.app"
    url: "https://graphical-auth-server.onrender.com"
}