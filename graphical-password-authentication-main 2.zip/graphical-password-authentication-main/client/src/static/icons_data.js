export var icons =
[
        {
            "id": "hSESTXkWdZ6P",
            "name": "goku",
            "url": "https://img.icons8.com/stickers/100/null/son-goku.png",
            "selected": false
        },
        {
            "id": "aoVDoLI_jNe5",
            "name": "rick",
            "url": "https://img.icons8.com/stickers/100/null/rick-sanchez.png",
            "selected": false
        },
        {
            "id": "wau71yfDiopJ",
            "name": "popeye",
            "url": "https://img.icons8.com/stickers/100/null/popeye.png",
            "selected": false
        },
        {
            "id": "2Aj56b5ynwJ5",
            "name": "ninjaturtle",
            "url": "https://img.icons8.com/stickers/100/null/ninja-turtle.png",
            "selected": false
        },
        {
            "id": "tni_yees8A-W",
            "name": "mario",
            "url": "https://img.icons8.com/stickers/100/null/super-mario.png",
            "selected": false
        },
        {
            "id": "cECvyZW_9kSe",
            "name": "hulk",
            "url": "https://img.icons8.com/stickers/100/null/hulk.png",
            "selected": false
        },
        {
            "id": "gKgo-53BO68B",
            "name": "naruto",
            "url": "https://img.icons8.com/stickers/100/null/naruto.png",
            "selected": false
        },
        {
            "id": "wqYlm6RuSl3Q",
            "name": "vader",
            "url": "https://img.icons8.com/stickers/100/null/darth-vader.png",
            "selected": false
        },
        {
            "id": "0bKJGNTVgolu",
            "name": "avatar",
            "url": "https://img.icons8.com/stickers/100/null/avatar.png",
            "selected": false
        },
    ]