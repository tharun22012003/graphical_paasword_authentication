export const Page = {
    HOME_PAGE: "home",
    SIGNUP_PAGE: "signup",
    ABOUT: "about",
    CONTACT: "contact",
    LOGIN_PAGE: "loginpage"
}

export const header = {headers: {"Access-Control-Allow-Origin": "*"}}