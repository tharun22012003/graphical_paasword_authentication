# Screenshots

### Landing Page
![image](https://user-images.githubusercontent.com/89336149/225679272-eeee628c-37f7-4a24-a999-e4388d9c82a5.png)

### Registration

![image](https://user-images.githubusercontent.com/89336149/225679685-d1a48458-09f5-4c40-a710-647d2734f0ff.png)
![image](https://user-images.githubusercontent.com/89336149/225680422-bf30a489-614f-4b81-a3eb-00e192b42380.png)

### Login

![image](https://user-images.githubusercontent.com/89336149/225681087-caefcf89-b558-4815-82be-a62fd9b7afad.png)
![image](https://user-images.githubusercontent.com/89336149/225681304-c98d74b1-431e-41ed-8837-ddf715f4daf9.png)

### Authentication Success
![image](https://user-images.githubusercontent.com/89336149/225681516-5d13b7e8-332b-48bc-a9e9-9b6151f06442.png)

### Authentication Fail
![image](https://user-images.githubusercontent.com/89336149/225682076-8c227151-c50c-4b54-8e33-548ba8dad548.png)

### Account Blocked
![image](https://user-images.githubusercontent.com/89336149/225682485-3eec611f-6deb-4aea-bcc9-cb323041eed8.png)

### Notification Email
![image](https://user-images.githubusercontent.com/89336149/225683001-87a9e730-fbbc-42b1-b799-c513691f8cbd.png)

### Account Unblock
![image](https://user-images.githubusercontent.com/89336149/225683133-aa210021-56e6-4722-aba8-6abb81adcd42.png)

